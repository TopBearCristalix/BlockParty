/**
 * Some file utils
 *
 * @author pauhull
 * @version 1.0
 */
package de.pauhull.utils.file;