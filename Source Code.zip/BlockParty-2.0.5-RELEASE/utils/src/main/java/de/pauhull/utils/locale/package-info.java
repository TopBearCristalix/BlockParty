/**
 * Utility for easy locale-management for your plugin
 *
 * @author pauhull
 * @version 1.0
 */
package de.pauhull.utils.locale;