/**
 * Utility for easy scheduler creation.
 *
 * @author pauhull
 * @version 1.0
 */
package de.pauhull.utils.scheduler;