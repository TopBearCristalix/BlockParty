/**
 * Classes for easy messaging over NMS.
 *
 * @author pauhull
 * @version 1.0
 */
package de.pauhull.utils.message;