package de.pauhull.utils.particle;

/**
 * Package de.pauhull.utils.particle
 *
 * @author Leon Koth
 * © 2019
 */
public interface IParticles {

    Object get();

}
