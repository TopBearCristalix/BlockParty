# Noteblock songs

Songs in this folder can be accessed by the noteblock api. 
Copy the songs (.nbs file) to this folder.

## Setup

To use noteblock songs for an arena, you have to edit your <arenaName>.yml file.

```yaml
UseNoteBlockSongs: true
UseWebSongs: false
SongManager:
    - song1
    - song2
```
