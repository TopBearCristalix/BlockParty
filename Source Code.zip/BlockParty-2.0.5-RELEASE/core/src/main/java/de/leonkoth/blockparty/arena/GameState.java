package de.leonkoth.blockparty.arena;

/**
 * Created by Leon on 21.09.2018.
 * Project BlockParty-2.0
 * © 2016 - Leon Koth
 */
public enum GameState {

    START, PLAY, STOP, WAIT

}
