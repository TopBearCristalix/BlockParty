package de.leonkoth.blockparty.arena;

/**
 * Created by Leon on 15.03.2018.
 * Project Blockparty2
 * © 2016 - Leon Koth
 */
public enum ArenaState {

    LOBBY, INGAME, ENDING

}
