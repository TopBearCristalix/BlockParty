package de.leonkoth.blockparty.player;

/**
 * Created by Leon on 15.03.2018.
 * Project Blockparty2
 * © 2016 - Leon Koth
 */
public enum PlayerState {

    DEFAULT, INLOBBY, INGAME, SPECTATING, WINNER

}
