/**
 * Utilities for images
 *
 * @author pauhull
 * @version 1.1
 */
package de.pauhull.utils.image;