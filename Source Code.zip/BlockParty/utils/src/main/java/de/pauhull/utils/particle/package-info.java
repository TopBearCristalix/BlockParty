/**
 * Utility to create particle effects with NMS
 *
 * @author pauhull
 * @version 1.1
 */
package de.pauhull.utils.particle;