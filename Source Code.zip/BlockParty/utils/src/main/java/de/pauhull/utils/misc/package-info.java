/**
 * Some classes that didn't fit anywhere else
 *
 * @author pauhull
 * @version 1.1
 */
package de.pauhull.utils.misc;