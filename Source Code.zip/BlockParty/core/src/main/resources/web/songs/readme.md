# Webplayer songs

Songs in this folder can be accessed by the webplayer. 
Copy the songs (for example: .mp3, .ogg file) to this folder.

## Setup

To use webplayer songs for an arena, you have to edit your <arenaName>.yml file.

```yaml
UseNoteBlockSongs: false
UseWebSongs: true
SongManager:
    - song1.mp3
    - song2.mp3
```
