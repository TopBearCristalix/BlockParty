package de.leonkoth.blockparty.boost;

public class PredictionBoost { //TODO
}
