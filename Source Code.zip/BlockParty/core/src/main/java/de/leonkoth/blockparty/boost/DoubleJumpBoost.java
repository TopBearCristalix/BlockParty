package de.leonkoth.blockparty.boost;

public class DoubleJumpBoost {
}
